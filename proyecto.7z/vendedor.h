#include <iostream>
using namespace std;

void clientes();
bool buscarCliente(string &codigo, string &nombreCliente);

