#include <iostream>
using namespace std;

void juegos();
bool buscarJuego(string &codigo, string &descripcionJuego);
