#include <iostream>
using namespace std;

void mensajeBienvenido();
void saltosDeLinea(int ciclos);
void mensajeEnConsola(string textoEnConsola);
void mensajeConValorEnConsola(string textoEnConsola, string &valorEnConsola);



