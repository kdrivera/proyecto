#include <iostream>
using namespace std;

void mensajeEnConsola(string textoEnConsola);
void mensajeConValorEnConsola(string textoEnConsola, string &valorEnConsola);

